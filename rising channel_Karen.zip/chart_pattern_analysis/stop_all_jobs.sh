pkill python
pkill mpirun
pkill nohup
