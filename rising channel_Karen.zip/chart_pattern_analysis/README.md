# chart_pattern_analysis
Development and analysis of chart patterns with tunable parameters for determination of predictive forecasts of profitable strategies.
